// Pass this function a number N to get an array
// containing N unique, randomized numbers.

// You don't need to touch this, but you will call
// to make your three arrays


function makeArray(number) {
	let array = []
	for (let i=0; i < number; ++i) {
		array[i]=i;
	}

	let tmp, current, top = array.length;

	if(top) {
			while(--top) {
				current = Math.floor(Math.random() * (top + 1));
				tmp = array[current];
				array[current] = array[top];
				array[top] = tmp;
		}
	}
	return array;
}
